extends Label

@onready var label: Label = $"."

func _process(delta):
	label.text = "Score: " + str(Globals.score)
